import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  ActivityIndicator,
  Alert,
  Dimensions,
  Platform,
} from "react-native";

const { width } = Dimensions.get("window");

// Small icon placeholder (simple text)
const Icon = ({ name, size = 20, color = "#fff", style = {} }) => (
  <Text style={[{ fontSize: size, color }, style]}>{name?.substring(0, 1) || "•"}</Text>
);

/* ----------------- CSV parsing ----------------- */
/**
 * Parses CSV text into an array of question objects.
 * Expects headers like 'Question', 'OptionA/1', 'OptionB/2', 'CorrectAnswer', 'Explanation'.
 * Handles quoted fields and maps headers correctly.
 */
const parseCSV = (csvText) => {
  if (!csvText || !csvText.trim()) return [];
  const lines = csvText.trim().split(/\r?\n/);
  if (lines.length === 0) return [];

  const rawHeaders = lines[0].split(",");
  const mapHeader = (header) => {
    const h = header.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (h.includes("optiona") || h.includes("option1")) return "option1";
    if (h.includes("optionb") || h.includes("option2")) return "option2";
    if (h.includes("optionc") || h.includes("option3")) return "option3";
    if (h.includes("optiond") || h.includes("option4")) return "option4";
    if (h.includes("question")) return "q";
    if (h.includes("correctanswer") || h.includes("correct")) return "correct";
    if (h.includes("explanation")) return "explanation";
    return null;
  };

  const headerMap = rawHeaders.map(mapHeader);

  const parseLine = (line) => {
    // Regex to split by comma, respecting quotes
    const matches = line.match(/(?:\"([^\"]*(?:\"\"[^\"]*)*)\")|([^,]+)/g);
    if (!matches) return [];
    return matches.map((match) => {
      if (match.startsWith('"') && match.endsWith('"')) {
        return match.substring(1, match.length - 1).replace(/""/g, '"').trim();
      }
      return match ? match.trim() : ''; // Handle empty matches
    });
  };

  const questions = [];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;
    const values = parseLine(lines[i]);
    if (values.length !== rawHeaders.length) {
      // Tolerate minor mismatch but warn
      console.warn(`Skipping line ${i + 1} due to mismatch in columns.`);
      continue;
    }
    const question = {};
    let options = [];
    let hasQuestionText = false;
    for (let j = 0; j < values.length; j++) {
      const mappedKey = headerMap[j];
      const value = values[j];
      if (mappedKey === "q") {
        question.q = value;
        hasQuestionText = true;
      } else if (mappedKey && mappedKey.startsWith("option")) {
        options.push(value);
      } else if (mappedKey === "correct") {
        // Normalize correct answer to uppercase single letter (A, B, C, D) if possible
        let correctValue = value.trim();
        if (correctValue.length === 1 && correctValue.match(/[A-Da-d1-4]/)) {
            question.correct = correctValue.toUpperCase();
        } else {
            // Otherwise, store the exact text (e.g., if the user wrote the full option text)
            question.correct = correctValue;
        }
      } else if (mappedKey === "explanation") {
        question.explanation = value;
      }
    }
    // Only add if it has question text, at least two options, and a correct answer marker
    if (hasQuestionText && options.length >= 2 && question.correct) {
      // Filter out empty options if they were included due to extra commas
      question.options = options.filter(opt => opt.trim() !== "");
      questions.push(question);
    }
  }
  return questions;
};

/* ----------------- Helper: shuffle ----------------- */
const shuffleArray = (array) => {
  const a = array.slice();
  let currentIndex = a.length, randomIndex;
  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [a[currentIndex], a[randomIndex]] = [a[randomIndex], a[currentIndex]];
  }
  return a;
};

/* ----------------- Main App ----------------- */
export default function App() {
  const [loading, setLoading] = useState(false);

  // Simple in-memory topics list (no firebase)
  const [topics, setTopics] = useState([]);
  const [quizState, setQuizState] = useState("TOPIC_SELECT"); // TOPIC_SELECT | PRACTICE | SUMMARY
  const [csvContent, setCsvContent] = useState("");
  const [newTopicName, setNewTopicName] = useState("");
  const [currentQuestions, setCurrentQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userResponses, setUserResponses] = useState({});
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [message, setMessage] = useState("");

  /**
   * Starts a new practice session with a given list of questions.
   */
  const startPractice = useCallback((questionsList) => {
    if (!questionsList || questionsList.length === 0) {
      setMessage("No questions to practice.");
      return;
    }
    // Assign unique IDs for reliable tracking if questions are reviewed later
    const withIds = shuffleArray(questionsList).map((q, i) => ({ ...q, id: `${i}-${Date.now()}` })); // Ensure questions are shuffled again
    setCurrentQuestions(withIds);
    setCurrentQuestionIndex(0);
    setUserResponses({});
    setQuizState("PRACTICE");
    setIsDrawerOpen(false);
  }, []);

  /**
   * Handles CSV import, parsing, and saving the new topic.
   */
  const handleImport = () => {
    if (!csvContent.trim()) { setMessage("Paste CSV content."); return; }
    if (!newTopicName.trim()) { setMessage("Enter topic name."); return; }
    
    setLoading(true);
    try {
        const parsed = parseCSV(csvContent);
        if (parsed.length === 0) { setMessage("No valid questions parsed. Check formatting."); setLoading(false); return; }
        
        // Check for duplicates (case-insensitive)
        if (topics.some(t => t.topicName.trim().toLowerCase() === newTopicName.trim().toLowerCase())) {
          setMessage("Topic with this name already exists.");
          setLoading(false);
          return;
        }
        
        const newTopic = { id: `topic-${Date.now()}`, topicName: newTopicName.trim(), questions: parsed };
        setTopics(prev => [newTopic, ...prev]);
        setCsvContent("");
        setNewTopicName("");
        setMessage(`Saved '${newTopic.topicName}' (${parsed.length} questions)`);
        setTimeout(()=>setMessage(""), 3000);
    } catch (error) {
        console.error("Import error:", error);
        setMessage("Error during CSV import.");
    } finally {
        setLoading(false);
    }
  };

  /**
   * Handles the deletion of a topic.
   */
  const handleDeleteTopic = (id, name) => {
    // Using simple Alert for non-web environments
    Alert.alert("Delete topic", `Are you sure you want to delete the topic "${name}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => setTopics(prev => prev.filter(t => t.id !== id)) }
    ]);
  };

  // Practice helpers
  const currentQuestion = useMemo(() => currentQuestions[currentQuestionIndex], [currentQuestions, currentQuestionIndex]);
  const currentResponse = userResponses[currentQuestionIndex] || { selectedOption: null, isCorrect: false, isExplanationVisible: false };

  /**
   * Checks if the selected option matches the correct answer based on content or index letter.
   */
  const checkAnswer = (selectedOption, question) => {
    if (!question || !question.correct) return false;
    
    const correctValue = question.correct?.trim?.();
    const selectedText = selectedOption?.trim?.();

    // 1. Check if the stored 'correct' value is a single letter (A, B, C, D)
    const correctCharMatch = correctValue.toUpperCase().match(/^[A-D]$/);
    if (correctCharMatch) {
        const correctIndex = correctCharMatch[0].charCodeAt(0) - 'A'.charCodeAt(0);
        const correctOptionText = question.options[correctIndex];
        return selectedText === correctOptionText?.trim?.();
    }
    
    // 2. Check if the stored 'correct' value is the full text of an option
    return selectedText === correctValue;
  };

  /**
   * Handles user selecting an option.
   */
  const handleOptionSelect = (option) => {
    const isCorrect = checkAnswer(option, currentQuestion);
    
    setUserResponses(prev => ({
      ...prev,
      [currentQuestionIndex]: {
        selectedOption: option,
        isCorrect,
        // Explanation visibility is now controlled only by the toggle, not selection status
        isExplanationVisible: prev[currentQuestionIndex]?.isExplanationVisible || false, 
      }
    }));
  };

  /**
   * Toggles the visibility of the explanation manually.
   */
  const toggleExplanation = () => {
    if (currentQuestion.explanation) {
      setUserResponses(prev => ({ 
        ...prev, 
        [currentQuestionIndex]: { 
          ...prev[currentQuestionIndex], 
          isExplanationVisible: !prev[currentQuestionIndex]?.isExplanationVisible 
        } 
      }));
    }
  };


  /**
   * Calculates the current score and identifies incorrect questions.
   */
  const calculateScore = useCallback(() => {
    let finalScore = 0, attempted = 0;
    const incorrects = [];
    Object.entries(userResponses).forEach(([k, r]) => {
      if (r?.selectedOption) {
        attempted++;
        if (r.isCorrect) {
          finalScore++;
        } else {
          const orig = currentQuestions[parseInt(k)];
          if (orig) incorrects.push(orig);
        }
      }
    });
    return { finalScore, attempted, total: currentQuestions.length, incorrects };
  }, [userResponses, currentQuestions]);

  // UI screens
  if (loading) return <View style={styles.centered}><ActivityIndicator size="large" color="#1D4ED8" /><Text>Loading...</Text></View>;

  if (quizState === "TOPIC_SELECT") {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>📚 MCQ - Topics</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Import CSV (paste)</Text>
          <TextInput value={newTopicName} onChangeText={setNewTopicName} placeholder="Enter Topic Name (e.g., 'React Hooks')" style={styles.input} />
          <TextInput value={csvContent} onChangeText={setCsvContent} placeholder="Paste CSV here (first row = headers)" style={[styles.input, { height: 140 }]} multiline />
          <TouchableOpacity onPress={handleImport} style={styles.primaryBtn}><Text style={styles.primaryBtnText}>Upload & Save Topic</Text></TouchableOpacity>
          {message ? <Text style={{ color: "#065F46", marginTop:8 }}>{message}</Text> : null}
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Available Topics</Text>
          {topics.length === 0 ? <Text style={{color:"#64748B"}}>No topics yet. Import CSV above.</Text> : topics.map(t => (
            <View key={t.id} style={styles.row}>
              <View style={{flex:1}}>
                <Text style={styles.topicName}>{t.topicName}</Text>
                <Text style={{color:"#64748B"}}>{t.questions.length} questions</Text>
              </View>
              <TouchableOpacity onPress={() => startPractice(t.questions)} style={styles.smallBtn}><Text style={{color:"#fff"}}>Practice</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteTopic(t.id, t.topicName)} style={[styles.smallBtn, {backgroundColor:"#EF4444", marginLeft:8}]}><Text style={{color:"#fff"}}><Icon name="X" size={14} /></Text></TouchableOpacity>
            </View>
          ))}
          {topics.length > 0 && <TouchableOpacity onPress={() => startPractice(topics.flatMap(t => t.questions))} style={[styles.primaryBtn, {marginTop:12, backgroundColor:"#F59E0B"}]}><Text style={styles.primaryBtnText}>Practice Random from ALL</Text></TouchableOpacity>}
        </View>
      </ScrollView>
    );
  }

  if (quizState === "PRACTICE") {
    const { finalScore, attempted } = calculateScore();
    const isAnswered = !!currentResponse.selectedOption;
    const questionNumber = currentQuestionIndex + 1;
    const totalQuestions = currentQuestions.length;
    const isLast = questionNumber === totalQuestions;

    return (
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.headerRow}>
          {/* Back Button (Top-Left) */}
          <TouchableOpacity onPress={() => setQuizState("TOPIC_SELECT")} style={styles.headerBtn}>
            <Text style={styles.headerBtnText}>🏠 Topics</Text>
          </TouchableOpacity>

          {/* Title */}
          <Text style={styles.headerTitle}>Q {questionNumber} / {totalQuestions}</Text> 

          {/* Navigator Button (Top-Right) */}
          <TouchableOpacity onPress={() => setIsDrawerOpen(prev => !prev)} style={styles.headerBtn}>
            <Text style={styles.headerBtnText}>List</Text>
          </TouchableOpacity>
        </View>


        <View style={styles.card}>
          {/* Question text (normal weight) */}
          <Text style={styles.question}>{currentQuestion?.q}</Text> 
          <View style={{marginTop:12}}>
            {currentQuestion?.options?.map((opt, idx) => {
              const label = String.fromCharCode(65 + idx);
              const isSelected = currentResponse.selectedOption === opt;
              // Check if this option is the correct one (only highlighted if answered)
              const isCorrectOption = isAnswered && checkAnswer(opt, currentQuestion); 
              
              let bg = "#fff", border="#E2E8F0", color="#0F172A";

              if (isAnswered) {
                  if (isCorrectOption) { // Correct option
                      // Highlight the correct answer
                      bg="#DCFCE7"; border="#34D399"; color="#065F46"; 
                  } else if (isSelected && !currentResponse.isCorrect) { // Incorrectly selected
                      // Highlight the user's incorrect choice
                      bg="#FFF1F2"; border="#FCA5A5"; color="#7F1D1D"; 
                  } else {
                      // Options that were not selected and are not correct remain neutral
                      bg="#F8FAFC"; border="#E2E8F0";
                  }
              } else {
                 // Pre-selection: Selected option is lightly highlighted
                 if (isSelected) {
                    bg="#EFF6FF"; border="#BFDBFE"; color="#1D4ED8";
                 }
              }

              return (
                <TouchableOpacity 
                  key={idx} 
                  onPress={() => handleOptionSelect(opt)} 
                  style={[styles.option, {backgroundColor:bg, borderColor:border}]}
                >
                  <Text style={{fontWeight:"700", marginRight:8, color}}>{label}.</Text>
                  <Text style={{flex:1, color}}>{opt}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* REMOVED: Correct/Incorrect Result Box as requested */}
          
          {/* Permanent Explanation Toggle (Plain Style) */}
          {currentQuestion.explanation && (
            <View style={{marginTop: 20, marginBottom: 10}}>
              <TouchableOpacity 
                onPress={toggleExplanation} 
                style={styles.plainToggle} // Use plain style
              >
                <Text style={{color:"#2563EB", fontWeight:"600", fontSize: 16}}>
                  {currentResponse.isExplanationVisible ? "Hide Explanation 🔺" : "Show Explanation 🔻"}
                </Text>
              </TouchableOpacity>
              {currentResponse.isExplanationVisible && 
                <View style={styles.explanationBox}>
                  <Text style={{color:"#1F2937", lineHeight: 22}}>{currentQuestion.explanation}</Text>
                </View>
              }
            </View>
          )}

          <View style={{flexDirection:"row", justifyContent:"space-between", marginTop:20}}>
            <TouchableOpacity 
              onPress={() => { 
                if (currentQuestionIndex > 0) setCurrentQuestionIndex(i=>i-1); 
                else setQuizState("TOPIC_SELECT"); 
              }} 
              style={[styles.navBtn, {backgroundColor:"#6B7280"}]}
            >
              <Text style={{color:"#fff", fontWeight:"600"}}>⬅️ Previous</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              onPress={() => { 
                if (isLast) setQuizState("SUMMARY"); 
                else setCurrentQuestionIndex(i=>i+1); 
              }} 
              style={[styles.navBtn, {backgroundColor: "#2563EB"}]}
            >
              <Text style={{color:"#fff", fontWeight:"600"}}>{isLast ? "Finish Session 🏆" : "Next ➡️"}</Text>
            </TouchableOpacity>
          </View>

          <Text style={{marginTop:10, color:"#475569", textAlign:"center"}}>Current Score: {finalScore} / {attempted} attempted</Text>
        </View>

        {isDrawerOpen && (
          <View style={styles.drawer}>
            <ScrollView>
              <Text style={{fontWeight:"700", marginBottom:12, fontSize:16, color:"#1F2937"}}>Question Navigator</Text>
              <View style={{flexDirection:"row", flexWrap:"wrap", justifyContent:"space-around"}}>
                {currentQuestions.map((q, i) => {
                  const resp = userResponses[i];
                  let bg="#E5E7EB", color="#374151";
                  if (resp?.selectedOption) { bg = resp.isCorrect ? "#059669" : "#DC2626"; color="#fff"; }
                  if (i === currentQuestionIndex) { bg="#2563EB"; color="#fff"; }
                  return (
                    <TouchableOpacity 
                      key={i} 
                      onPress={() => { setCurrentQuestionIndex(i); setIsDrawerOpen(false); }} 
                      style={{width:"18%", aspectRatio:1, margin:4, justifyContent:"center", alignItems:"center", backgroundColor:bg, borderRadius:8}}
                    >
                      <Text style={{color, fontWeight:"700"}}>{i+1}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              <TouchableOpacity onPress={() => setIsDrawerOpen(false)} style={[styles.primaryBtn, {marginTop:16, backgroundColor:"#6B7280"}]}><Text style={styles.primaryBtnText}>Close</Text></TouchableOpacity>
            </ScrollView>
          </View>
        )}
      </ScrollView>
    );
  }

  if (quizState === "SUMMARY") {
    const { finalScore, attempted, total, incorrects } = calculateScore();
    const accuracy = attempted > 0 ? Math.round((finalScore / attempted) * 100) : 0;

    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>🎉 Session Complete!</Text>
        <View style={styles.card}>
          <Text style={styles.question}>Summary Results</Text>
          <Text style={{marginTop:12, fontSize:16, color:"#1F2937"}}>Total Questions: <Text style={{fontWeight:"700"}}>{total}</Text></Text>
          <Text style={{marginTop:6, fontSize:16, color:"#1F2937"}}>Attempted: <Text style={{fontWeight:"700"}}>{attempted}</Text></Text>
          <Text style={{marginTop:6, fontSize:18, color:"#065F46"}}>Correct: <Text style={{fontWeight:"800"}}>{finalScore}</Text></Text>
          <Text style={{marginTop:12, fontSize:20, fontWeight:"800", color:"#1D4ED8"}}>Accuracy: {accuracy}%</Text>
          
          <View style={{flexDirection:"row", marginTop:24}}>
            <TouchableOpacity onPress={() => { setQuizState("TOPIC_SELECT"); }} style={[styles.primaryBtn, {flex:1, marginRight:8, backgroundColor:"#6B7280"}]}><Text style={styles.primaryBtnText}>Back to Topics</Text></TouchableOpacity>
            {incorrects.length > 0 && 
              <TouchableOpacity onPress={() => startPractice(incorrects)} style={[styles.primaryBtn, {flex:1, backgroundColor:"#EF4444"}]}><Text style={styles.primaryBtnText}>Review {incorrects.length} Incorrect</Text></TouchableOpacity>
            }
          </View>
        </View>
      </ScrollView>
    );
  }

  return null;
}

/* ----------------- Styles ----------------- */
const styles = StyleSheet.create({
  // Status Bar Clearance (High Padding)
  container: { 
    padding: 16, 
    paddingTop: Platform.OS === 'android' ? 40 : 60, // Increased padding
    paddingBottom: 60, 
    backgroundColor: "#F3F4F6", 
    minHeight: "100%" 
  },
  centered: { flex:1, justifyContent:"center", alignItems:"center" },
  title: { fontSize:24, fontWeight:"800", color:"#1D4ED8", marginBottom:16 },
  
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: "#1D4ED8",
  },
  headerBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: "#EFF6FF",
    borderWidth: 1,
    borderColor: "#BFDBFE",
  },
  headerBtnText: {
    color: "#1D4ED8",
    fontWeight: "600",
  },

  card: { backgroundColor:"#fff", padding:16, borderRadius:16, marginBottom:16, shadowColor:"#000", shadowOpacity:0.1, shadowRadius:5, elevation:5 },
  cardTitle: { fontWeight:"800", fontSize:18, color:"#374151", marginBottom:10 },
  input: { borderWidth:1, borderColor:"#D1D5DB", padding:12, borderRadius:10, backgroundColor:"#fff", marginBottom:10, color:"#1F2937" },
  primaryBtn: { backgroundColor:"#10B981", padding:14, borderRadius:10, alignItems:"center", marginTop:12, shadowColor:"#10B981", shadowOpacity:0.3, shadowRadius:4, elevation:3 },
  primaryBtnText: { color:"#fff", fontWeight:"700", fontSize:16 },
  row: { flexDirection:"row", alignItems:"center", justifyContent:"space-between", paddingVertical:10, borderBottomWidth:1, borderBottomColor:"#F3F4F6" },
  topicName: { fontWeight:"700", fontSize:16, color:"#1F2937" },
  smallBtn: { backgroundColor:"#2563EB", paddingHorizontal:12, paddingVertical:6, borderRadius:8, shadowColor:"#2563EB", shadowOpacity:0.3, shadowRadius:4, elevation:3 },
  smallBtnAlt: { paddingHorizontal:12, paddingVertical:6, borderRadius:8, backgroundColor:"#EFF6FF", borderWidth:1, borderColor:"#BFDBFE" },
  // Question text (normal weight)
  question: { fontSize:18, fontWeight:"500", color:"#1F2937" },
  option: { flexDirection:"row", alignItems:"flex-start", padding:14, borderRadius:12, borderWidth:2, marginBottom:10, transitionDuration: '0.2s' },
  box: { padding:12, borderRadius:12, borderWidth:2 },
  navBtn: { paddingHorizontal:16, paddingVertical:12, borderRadius:10, shadowColor:"#000", shadowOpacity:0.1, shadowRadius:3, elevation:2 },
  drawer: { position:"absolute", right:16, top:100, width: width * 0.8, maxHeight: "70%", backgroundColor:"#fff", padding:16, borderRadius:16, elevation:10, shadowColor:"#000", shadowOpacity:0.2, shadowRadius:10, zIndex:100 },

  // Styles for permanent, plain explanation toggle
  plainToggle: {
    alignItems: 'flex-start', // Align left for better readability
    paddingVertical: 8,
  },
  explanationBox: {
    padding: 12,
    backgroundColor: '#F3F4F6', 
    borderRadius: 8,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  }
});

